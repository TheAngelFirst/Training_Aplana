Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

///*Correlation comment - Do not change!  Original value='127663.354232483zfzzziDpHiDDDDDDDQtAApVAcH' Name ='userSession' Type ='ResponseBased'*/
//	web_reg_save_param_attrib(
//		"ParamName=userSession",
//		"TagName=input",
//		"Extract=value",
//		"Name=userSession",
//		"Type=hidden",
//		SEARCH_FILTERS,
//		"IgnoreRedirections=No",
//		"RequestUrl=*/nav.pl*",
//		LAST);

	lr_start_transaction("S1_T1_�������_������_������");

	web_reg_save_param_ex(
		"ParamName=userSession",
		"LB=userSession\" value=\"",
		"RB=\"/>",
		SEARCH_FILTERS,
		LAST);

	web_url("welcome.pl", 
		"URL=http://192.168.1.2:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/WebTours/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	/* LOGIN */

	lr_think_time(21);

	lr_start_transaction("S1_T11_�����");
	
	web_reg_find("Text=User password was correct", LAST);
	web_submit_data("login.pl",
		"Action=http://192.168.1.2:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://192.168.1.2:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t30.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value=bean", ENDITEM,
		"Name=login.x", "Value=59", ENDITEM,
		"Name=login.y", "Value=2", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("S1_T11_�����", LR_AUTO);
	
	/* LOGIN\ */
	/* FLIGHTS */

	lr_think_time(27);

	lr_start_transaction("S1_T12_�����_������");
	
	web_url("Search Flights Button", 
		"URL=http://192.168.1.2:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	/* FLIGHTS\
	   FIND FLIGHTS */

	lr_think_time(41);

	web_submit_data("reservations.pl", 
		"Action=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=12/11/2019", ENDITEM, 
		"Name=arrive", "Value=Denver", ENDITEM, 
		"Name=returnDate", "Value=12/12/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=32", ENDITEM, 
		"Name=findFlights.y", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_think_time(6);

	web_submit_data("reservations.pl_2", 
		"Action=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=000;0;12/11/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=reserveFlights.x", "Value=68", ENDITEM, 
		"Name=reserveFlights.y", "Value=13", ENDITEM, 
		LAST);

	lr_end_transaction("S1_T12_�����_������", LR_AUTO);
	
	/* 2 FIND FLIGHTS\ */

	/* PAYMENT DETAILS */

	lr_think_time(48);

	lr_start_transaction("S1_T13_������_������");
	
	web_submit_data("reservations.pl_3", 
		"Action=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=123456789", ENDITEM, 
		"Name=expDate", "Value=2019", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=outboundFlight", "Value=000;0;12/11/2019", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=35", ENDITEM, 
		"Name=buyFlights.y", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);
	
	lr_end_transaction("S1_T13_������_������", LR_AUTO);
	
	/* PAYMENT DETAILS\
	   INVOICE */

	lr_think_time(46);

	web_submit_data("reservations.pl_4", 
		"Action=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=Book Another.x", "Value=46", ENDITEM, 
		"Name=Book Another.y", "Value=13", ENDITEM, 
		LAST);

	/* INVOICE\
	   BOOK ANOTHER */
	
	lr_end_transaction("S1_T1_�������_������_������", LR_AUTO);
	
	return 0;
}