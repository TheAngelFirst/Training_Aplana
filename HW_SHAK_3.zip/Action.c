Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");
	
	lr_start_transaction("S3_T1_��������_���������_������");

	web_reg_save_param_ex(
		"ParamName=userSession",
		"LB=userSession\" value=\"",
		"RB=\"/>",
		SEARCH_FILTERS,
		LAST);
	
	web_url("welcome.pl", 
		"URL=http://192.168.1.2:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/WebTours/", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("S3_T11_�����_2_�������");

	lr_think_time(138);
	web_reg_find("Text=User password was incorrect", LAST);
	web_submit_data("login.pl",
		"Action=http://192.168.1.2:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://192.168.1.2:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t35.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value=be", ENDITEM,
		"Name=login.x", "Value=53", ENDITEM,
		"Name=login.y", "Value=10", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_think_time(9);
	
	web_reg_find("Text=User password was correct", LAST);
	web_submit_data("login.pl_2",
		"Action=http://192.168.1.2:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://192.168.1.2:1080/cgi-bin/nav.pl?username=jojo&password=be",
		"Snapshot=t36.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value=bean", ENDITEM,
		"Name=login.x", "Value=81", ENDITEM,
		"Name=login.y", "Value=10", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("S3_T11_�����_2_�������",LR_AUTO);

	lr_think_time(55);

	lr_start_transaction("S3_T12_�������_��_�������_Flights");

	web_url("Search Flights Button", 
		"URL=http://192.168.1.2:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("S3_T12_�������_��_�������_Flights",LR_AUTO);

	lr_start_transaction("S3_T13_�����_�����");

	lr_think_time(52);

	web_submit_data("reservations.pl", 
		"Action=http://192.168.1.2:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=12/11/2019", ENDITEM, 
		"Name=arrive", "Value=Denver", ENDITEM, 
		"Name=returnDate", "Value=12/12/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=62", ENDITEM, 
		"Name=findFlights.y", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("S3_T13_�����_�����",LR_AUTO);

	lr_think_time(81);

	lr_start_transaction("S3_T14_�������_��_HomePage");

	web_url("Home Button", 
		"URL=http://192.168.1.2:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.1.2:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("S3_T14_�������_��_HomePage",LR_AUTO);

	lr_end_transaction("S3_T1_��������_���������_������",LR_AUTO);

	return 0;
}